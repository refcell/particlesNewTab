self.__precacheManifest = [
  {
    "revision": "5ba8b49557cb89819dfd",
    "url": "/static/css/main.dda02e3c.chunk.css"
  },
  {
    "revision": "5ba8b49557cb89819dfd",
    "url": "/static/js/main.f600e1d2.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "4428f207c66a89eeee04",
    "url": "/static/css/2.d544f40d.chunk.css"
  },
  {
    "revision": "4428f207c66a89eeee04",
    "url": "/static/js/2.e816805a.chunk.js"
  },
  {
    "revision": "b82cbc7a498e988c901d2164814b2556",
    "url": "/index.html"
  }
];